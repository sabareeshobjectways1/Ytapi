export interface AnimeInfo {
  id: string;
  title: string;
  image: string;
  cover: string;
  description: string;
  genres: string[];
  status: string;
  totalEpisodes: number;
  releaseDate: string;
  rating: number;
  episodes: Episode[];
}

export interface Episode {
  id: string;
  number: number;
  title: string;
  image: string;
  description: string;
}

export interface StreamingSource {
  url: string;
  quality: string;
  isM3U8: boolean;
}