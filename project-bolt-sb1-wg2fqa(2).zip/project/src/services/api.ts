import axios from 'axios';
import { AnimeInfo, Episode, StreamingSource } from '../types/anime';
import toast from 'react-hot-toast';

const BASE_URL = 'https://consumet-api-green-nu.vercel.app/anime/gogoanime';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.message || 'An error occurred';
    toast.error(message);
    return Promise.reject(error);
  }
);

export const getRecentAnime = async (page = 1): Promise<AnimeInfo[]> => {
  const { data } = await api.get(`/recent-episodes?page=${page}`);
  return data.results.map((anime: any) => ({
    id: anime.id,
    title: anime.title,
    image: anime.image || 'https://via.placeholder.com/225x320',
    cover: anime.cover || anime.image || 'https://via.placeholder.com/1920x1080',
    description: anime.description || 'No description available.',
    genres: anime.genres || [],
    status: anime.status || 'Unknown',
    totalEpisodes: anime.totalEpisodes || 0,
    releaseDate: anime.releaseDate || 'Unknown',
    rating: anime.rating || 0,
    episodes: []
  }));
};

export const getPopularAnime = async (page = 1): Promise<AnimeInfo[]> => {
  const { data } = await api.get(`/top-airing?page=${page}`);
  return data.results.map((anime: any) => ({
    id: anime.id,
    title: anime.title,
    image: anime.image || 'https://via.placeholder.com/225x320',
    cover: anime.cover || anime.image || 'https://via.placeholder.com/1920x1080',
    description: anime.description || 'No description available.',
    genres: anime.genres || [],
    status: anime.status || 'Unknown',
    totalEpisodes: anime.totalEpisodes || 0,
    releaseDate: anime.releaseDate || 'Unknown',
    rating: anime.rating || 0,
    episodes: []
  }));
};

export const searchAnime = async (query: string): Promise<AnimeInfo[]> => {
  if (!query.trim()) return [];
  const { data } = await api.get(`/${encodeURIComponent(query)}`);
  return data.results.map((anime: any) => ({
    id: anime.id,
    title: anime.title,
    image: anime.image || 'https://via.placeholder.com/225x320',
    cover: anime.cover || anime.image || 'https://via.placeholder.com/1920x1080',
    description: anime.description || 'No description available.',
    genres: anime.genres || [],
    status: anime.status || 'Unknown',
    totalEpisodes: anime.totalEpisodes || 0,
    releaseDate: anime.releaseDate || 'Unknown',
    rating: anime.rating || 0,
    episodes: []
  }));
};

export const getAnimeInfo = async (id: string): Promise<AnimeInfo> => {
  const { data } = await api.get(`/info/${id}`);
  return {
    id: data.id,
    title: data.title,
    image: data.image || 'https://via.placeholder.com/225x320',
    cover: data.cover || data.image || 'https://via.placeholder.com/1920x1080',
    description: data.description || 'No description available.',
    genres: data.genres || [],
    status: data.status || 'Unknown',
    totalEpisodes: data.totalEpisodes || 0,
    releaseDate: data.releaseDate || 'Unknown',
    rating: data.rating || 0,
    episodes: (data.episodes || []).map((ep: any) => ({
      id: ep.id,
      number: ep.number,
      title: `Episode ${ep.number}`,
      image: ep.image || data.image || 'https://via.placeholder.com/225x320',
      description: ep.description || `Episode ${ep.number} of ${data.title}`
    }))
  };
};

export const getEpisodeSources = async (episodeId: string): Promise<StreamingSource[]> => {
  try {
    const { data } = await api.get(`/watch/${episodeId}`);
    
    // Filter out non-working sources and ensure we have direct URLs
    const workingSources = data.sources
      .filter((source: any) => source.url && !source.url.includes('streamsb.net'))
      .map((source: any) => ({
        url: source.url,
        quality: source.quality,
        isM3U8: source.isM3U8
      }));

    if (workingSources.length === 0) {
      throw new Error('No valid streaming sources found');
    }

    return workingSources;
  } catch (error) {
    console.error('Error fetching episode sources:', error);
    throw error;
  }
};