import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Play } from 'lucide-react';
import { AnimeInfo } from '../types/anime';
import { clsx } from 'clsx';

interface AnimeCardProps {
  anime: AnimeInfo;
  featured?: boolean;
}

export const AnimeCard: React.FC<AnimeCardProps> = ({ anime, featured = false }) => {
  return (
    <Link 
      to={`/anime/${anime.id}`} 
      className={clsx(
        "group relative overflow-hidden rounded-lg shadow-lg",
        featured ? "col-span-2 row-span-2" : ""
      )}
    >
      <div className="aspect-[3/4]">
        <img
          src={featured ? anime.cover : anime.image}
          alt={anime.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent">
          <div className="absolute bottom-0 p-4 w-full">
            <h3 className="text-white font-semibold text-lg mb-2">{anime.title}</h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-yellow-400">
                <Star className="w-4 h-4 fill-current mr-1" />
                <span className="text-sm">{anime.rating}</span>
              </div>
              {featured && (
                <div className="flex items-center text-blue-400">
                  <Play className="w-4 h-4 fill-current mr-1" />
                  <span className="text-sm">{anime.totalEpisodes} Episodes</span>
                </div>
              )}
            </div>
            {featured && (
              <p className="text-gray-300 text-sm mt-2 line-clamp-2">
                {anime.description}
              </p>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};