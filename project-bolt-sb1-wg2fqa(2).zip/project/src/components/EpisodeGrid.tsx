import React from 'react';
import { Link } from 'react-router-dom';
import { Episode } from '../types/anime';

interface EpisodeGridProps {
  episodes: Episode[];
  animeId: string;
}

export const EpisodeGrid: React.FC<EpisodeGridProps> = ({ episodes, animeId }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
      {episodes.map((episode) => (
        <Link
          key={episode.id}
          to={`/watch/${animeId}/${episode.id}`}
          className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-blue-500 transition"
        >
          <div className="aspect-video relative">
            <img
              src={episode.image}
              alt={`Episode ${episode.number}`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-2">
              <span className="text-white text-sm">Episode {episode.number}</span>
            </div>
          </div>
          <div className="p-2">
            <h4 className="text-white text-sm line-clamp-1">{episode.title}</h4>
          </div>
        </Link>
      ))}
    </div>
  );
};