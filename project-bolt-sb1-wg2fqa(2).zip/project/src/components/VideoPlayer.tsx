import React, { useState } from 'react';
import ReactPlayer from 'react-player';
import { StreamingSource } from '../types/anime';
import { toast } from 'react-hot-toast';

interface VideoPlayerProps {
  sources: StreamingSource[];
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ sources }) => {
  const [currentSource, setCurrentSource] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const handleError = () => {
    if (currentSource < sources.length - 1) {
      toast.error('Current source failed, trying next source...');
      setCurrentSource(prev => prev + 1);
    } else {
      toast.error('Failed to play video. Please try again later.');
    }
  };

  return (
    <div className="relative">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
        </div>
      )}
      <div className="aspect-video bg-black rounded-lg overflow-hidden">
        <ReactPlayer
          key={currentSource} // Force remount when source changes
          url={sources[currentSource].url}
          controls
          width="100%"
          height="100%"
          playing
          onError={handleError}
          onBuffer={() => setIsLoading(true)}
          onBufferEnd={() => setIsLoading(false)}
          onReady={() => setIsLoading(false)}
          config={{
            file: {
              forceHLS: sources[currentSource].isM3U8,
              attributes: {
                crossOrigin: "anonymous"
              }
            }
          }}
        />
      </div>
      <div className="mt-4 flex gap-2">
        {sources.map((source, index) => (
          <button
            key={index}
            onClick={() => setCurrentSource(index)}
            className={`px-3 py-1 rounded ${
              currentSource === index
                ? 'bg-blue-500 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            {source.quality}
          </button>
        ))}
      </div>
    </div>
  );
};