import React from 'react';
import { useQuery } from 'react-query';
import { getPopularAnime, getRecentAnime } from '../services/api';
import { AnimeCard } from '../components/AnimeCard';
import { Navbar } from '../components/Navbar';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';
import { toast } from 'react-hot-toast';

export const HomePage: React.FC = () => {
  const { data: popularAnime, isError: popularError } = useQuery('popularAnime', () => getPopularAnime(), {
    onError: () => toast.error('Failed to load popular anime')
  });

  const { data: recentAnime, isError: recentError } = useQuery('recentAnime', () => getRecentAnime(), {
    onError: () => toast.error('Failed to load recent anime')
  });

  if (popularError && recentError) {
    return (
      <div className="min-h-screen bg-gray-900 text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Unable to load content</h2>
            <p>Please try again later</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Slider */}
        {popularAnime && popularAnime.length > 0 && (
          <section className="mb-12">
            <Swiper
              modules={[Autoplay, Pagination]}
              autoplay={{ delay: 5000 }}
              pagination={{ clickable: true }}
              className="rounded-xl overflow-hidden"
            >
              {popularAnime.slice(0, 5).map((anime) => (
                <SwiperSlide key={anime.id}>
                  <div className="relative aspect-[21/9]">
                    <img
                      src={anime.cover || anime.image}
                      alt={anime.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent">
                      <div className="absolute bottom-0 p-8">
                        <h2 className="text-4xl font-bold text-white mb-4">{anime.title}</h2>
                        <p className="text-gray-200 max-w-2xl mb-6 line-clamp-2">
                          {anime.description}
                        </p>
                        <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">
                          Watch Now
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </section>
        )}

        {/* Popular Anime */}
        {popularAnime && popularAnime.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">Popular Anime</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {popularAnime.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          </section>
        )}

        {/* Recent Episodes */}
        {recentAnime && recentAnime.length > 0 && (
          <section>
            <h2 className="text-2xl font-bold text-white mb-6">Recent Episodes</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {recentAnime.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
};