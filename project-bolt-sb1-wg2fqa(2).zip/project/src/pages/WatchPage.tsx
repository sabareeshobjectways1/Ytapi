import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from 'react-query';
import { getEpisodeSources } from '../services/api';
import { Navbar } from '../components/Navbar';
import { VideoPlayer } from '../components/VideoPlayer';

export const WatchPage: React.FC = () => {
  const { episodeId } = useParams<{ episodeId: string }>();
  const { data: sources, isLoading } = useQuery(
    ['episode', episodeId],
    () => getEpisodeSources(episodeId!)
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!sources) return null;

  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <VideoPlayer sources={sources} />
      </main>
    </div>
  );
};