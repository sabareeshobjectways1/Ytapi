import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from 'react-query';
import { getAnimeInfo } from '../services/api';
import { Navbar } from '../components/Navbar';
import { EpisodeGrid } from '../components/EpisodeGrid';
import { Star, Calendar, Play } from 'lucide-react';

export const AnimePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data: anime, isLoading } = useQuery(['anime', id], () => getAnimeInfo(id!));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!anime) return null;

  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      
      <div className="relative">
        <div className="h-[50vh] relative">
          <img
            src={anime.cover}
            alt={anime.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent">
            <div className="container mx-auto px-4 h-full flex items-end pb-8">
              <div className="flex gap-8">
                <img
                  src={anime.image}
                  alt={anime.title}
                  className="w-48 rounded-lg shadow-lg"
                />
                <div className="text-white">
                  <h1 className="text-4xl font-bold mb-4">{anime.title}</h1>
                  <div className="flex items-center space-x-6 mb-4">
                    <div className="flex items-center">
                      <Star className="w-5 h-5 text-yellow-400 fill-yellow-400 mr-2" />
                      <span>{anime.rating}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="w-5 h-5 mr-2" />
                      <span>{anime.releaseDate}</span>
                    </div>
                    <div className="flex items-center">
                      <Play className="w-5 h-5 mr-2" />
                      <span>{anime.totalEpisodes} episodes</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {anime.genres.map((genre) => (
                      <span
                        key={genre}
                        className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm"
                      >
                        {genre}
                      </span>
                    ))}
                  </div>
                  <p className="text-gray-300 max-w-2xl">{anime.description}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold text-white mb-6">Episodes</h2>
        <EpisodeGrid episodes={anime.episodes} animeId={anime.id} />
      </main>
    </div>
  );
};